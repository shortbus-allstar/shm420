return {
	['newcond'] = {
		['tar'] = 'None',
		['cond'] = '',
		['type'] = 'spell',
		['name'] = '',
	},
}