return {
	['hovered'] = '(0.6,0,0.8,1)',
	['active'] = '(0.7,0,0.9,1)',
	['button'] = '(0.4,0,0.6,1)',
	['windowbg'] = '(0.2,0.2,0.2,0.8)',
	['name'] = 'Purple Transformer',
	['text'] = '(1,1,1,1)',
	['bg'] = '(0.5,0,0.7,1)',
}