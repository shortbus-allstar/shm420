return {
	[1] = {
		['cmd'] = '/echo #1# sent me a tell',
		['loopdelay'] = '0',
		['cmddelay'] = '10',
		['trig'] = '#1# tells you, #*#',
	},
	['newevent'] = {
		['cmd'] = '',
		['loopdelay'] = 0,
		['cmddelay'] = 10,
		['trig'] = '',
	},
	[2] = {
		['cmd'] = '/multiline ; /stopcast ; /timed 2 /tar #1# ; /timed 5 /cast 1',
		['loopdelay'] = '4500',
		['cmddelay'] = '100',
		['trig'] = '#1# tells the group, \'Heal me\'',
	},
}